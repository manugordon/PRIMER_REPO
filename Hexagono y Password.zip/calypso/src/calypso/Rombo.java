package calypso;

public class Rombo {
	
////	Hice dos variables: "filas" y "columnas", 
//  las cuales se utilizan para controlar el tamaño del rombo. El primer for se utiliza para dibujar la 
//   parte superior del rombo, mientras que el segundo for se utiliza para dibujar la parte inferior. 
//  Los for internos se utilizan para imprimir los asteriscos y los espacios necesarios para dar forma al rombo

    public void pintar(int filas, int columnas) {
    	for (int i = 0; i <= filas; i++) {
            for (int j = 0; j <= columnas - i; j++) {
                System.out.print(" ");
            }
            for (int j = 0; j < 2 * i - 1; j++) {
                System.out.print("*");
            }
            System.out.println();
        }
    	
    	// Este lo que hace es dibujar el triangulo pero al reves
    	
        for (int i = filas - 1; i >= 0; i--) {
            for (int j = 0; j <= columnas - i; j++) {
                System.out.print(" ");
            }
            for (int j = 0; j < 2 * i - 1; j++) {
                System.out.print("*");
            }
            System.out.println();
        }
        
        }
 
    }
    

