package calypso;

public class Ejercicio7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  Scanner sc = new Scanner(System.in);
	        int hora, minutos, segundos;

	        System.out.print("Ingrese la hora (formato: hh): ");
	        hora = sc.nextInt();
	        System.out.print("Ingrese los minutos (formato: mm): ");
	        minutos = sc.nextInt();
	        System.out.print("Ingrese los segundos (formato: ss): ");
	        segundos = sc.nextInt();

	        if (hora >= 0 && hora <= 23) {
	            if (minutos >= 0 && minutos <= 59) {
	                if (segundos >= 0 && segundos <= 59) {
	                    System.out.println("La hora es válida.");
	                } else {
	                    System.out.println("Los segundos no son válidos.");
	                }
	            } else {
	                System.out.println("Los minutos no son válidos.");
	            }
	        } else {
	            System.out.println("La hora no es válida.");
	        }

}
	}
