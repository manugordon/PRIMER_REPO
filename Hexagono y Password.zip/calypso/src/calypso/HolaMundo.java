package calypso;


public class HolaMundo {

	public static void main(String[] args) {
	
		Rombo b1 = new Rombo();
				b1.pintar(4, 10);
	}

}
