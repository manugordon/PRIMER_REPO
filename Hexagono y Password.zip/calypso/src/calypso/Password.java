package calypso;

public class Password {
    private int longitud;
    private String contrasena;
    
    // POR DEFECTO
    public Password() {
        this.longitud = 8;
        this.contrasena = "hola1234";
    }
    //SOBRECARGADOS
    public Password(String contrasena) {
        this.longitud = 8;
        this.contrasena = contrasena;
    }
    
    public Password(String contrasena, int longitud) {
        this.longitud = longitud;
        this.contrasena = contrasena;
    }
    
    // DE COPIA
    public Password(Password p) {
    	this.longitud = p.longitud;
    	this.contrasena = p.contrasena;
    }
    // METODO ES FUERTE
    public boolean esFuerte() {
    	int numMayusculas = 0;
        int numMinusculas = 0;
        int numNumeros = 0;
        
        for (int i = 0; i < contrasena.length(); i++) {
            char caracter = contrasena.charAt(i);
            if (Character.isUpperCase(caracter)) {
                numMayusculas++;
            } else if (Character.isLowerCase(caracter)) {
                numMinusculas++;
            } else if (Character.isDigit(caracter)) {
                numNumeros++;
            }
        }
        
        return (numMayusculas > 2 && numMinusculas > 1 && numNumeros > 5);
    }
    // METODO GENERAR PASSWORD
    // realmente busque el metodo string builder y random en internet para generar la contrasena
    public void generarPassword() {
        String caracteres = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        StringBuilder sb = new StringBuilder();
        Random rand = new Random();
        for (int i = 0; i < longitud; i++) {
            sb.append(caracteres.charAt(rand.nextInt(caracteres.length())));
        }
        this.contrasena = sb.toString();
    }

    // GETTERS PARA LONGITUD Y CONTRASENA
    public int getLongitud() {
        return longitud;
    }
    
    public String getContrasena() {
        return contrasena;
    }
    // SET PARA LONGITUD
    public void setLongitud(int longitud) {
        this.longitud = longitud;
    }
    

}
